int* gerarVetorOrdenado(int tam, int vet[]);

void gerarVetPesquisa(int tamP, int pesq[], int tamV, int vet[]);

int* gerarVetorDesordenado(int tam, int vet[]);

int buscaSequencialVetor(int tam, int vet[], int valor);

int buscaBinaria(int tam, int vet[], int valor);

void duplica(int tam, int vet[], int cpy[]);

void insertionSort(int tam, int vet[]);

void bubbleSort(int tam, int vet[]);

void quickSort(int tam, int vet[]);

void gerarVetorParcialmenteOrdenado(int tam, int vet[]);

void percorrerVetor(int tam, int vet[]);

int* gerarVetorDesordenadoSemRepeticoes(int tam, int vet[]);
